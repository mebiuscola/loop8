import {readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {validateReport,reportSummary} from './report-contract.mjs';
const [reportPath,sourcePath]=process.argv.slice(2);
if(!reportPath||!sourcePath){console.error('Usage: node validate_report.mjs report.json original.pptx');process.exitCode=1;}
else try{const hash=createHash('sha256').update(await readFile(sourcePath)).digest('hex');const report=validateReport(JSON.parse(await readFile(reportPath,'utf8')),hash);console.log(JSON.stringify({valid:true,...reportSummary(report)}));}catch(e){console.error(e.message);process.exitCode=1;}
