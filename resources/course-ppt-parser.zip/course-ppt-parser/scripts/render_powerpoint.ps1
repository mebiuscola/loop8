param(
 [Parameter(Mandatory=$true)][string]$InputPath,
 [Parameter(Mandatory=$true)][string]$OutDir,
 [int]$Width=1800
)
$ErrorActionPreference='Stop'
$original=(Resolve-Path -LiteralPath $InputPath).Path
$output=[IO.Path]::GetFullPath($OutDir)
if([IO.Path]::GetExtension($original).ToLowerInvariant() -notin @('.ppt','.pptx')) { throw 'Use an original PPT or PPTX.' }
if($Width -lt 800 -or $Width -gt 4000) { throw 'Width must be 800–4000.' }
New-Item -ItemType Directory -Path $output -Force | Out-Null
$existing=@(Get-Process -Name POWERPNT -ErrorAction SilentlyContinue)
$application=$null;$presentation=$null;$oldSecurity=$null
try {
 $application=New-Object -ComObject PowerPoint.Application
 $oldSecurity=$application.AutomationSecurity
 $application.AutomationSecurity=3
 $presentation=$application.Presentations.Open($original,-1,0,0)
 $pages=@();$height=[int]($Width*$presentation.PageSetup.SlideHeight/$presentation.PageSetup.SlideWidth)
 for($number=1;$number -le $presentation.Slides.Count;$number++) {
  $slide=$presentation.Slides.Item($number)
  $target=Join-Path $output ('page-{0:d4}.png' -f $number)
  $slide.Export($target,'PNG',$Width,$height)
  $texts=@();$notes=@()
  foreach($shape in $slide.Shapes) {
   if($shape.HasTextFrame -eq -1 -and $shape.TextFrame.HasText -eq -1) { $texts+=$shape.TextFrame.TextRange.Text }
   if($shape.HasTable -eq -1) { for($r=1;$r -le $shape.Table.Rows.Count;$r++) { $cells=@();for($c=1;$c -le $shape.Table.Columns.Count;$c++) { $cells+=$shape.Table.Cell($r,$c).Shape.TextFrame.TextRange.Text };$texts+=($cells -join ' | ') } }
  }
  foreach($shape in $slide.NotesPage.Shapes) {
   if($shape.Type -eq 14 -and $shape.PlaceholderFormat.Type -eq 2 -and $shape.HasTextFrame -eq -1) { $notes+=$shape.TextFrame.TextRange.Text }
  }
  $pages+=@{page=$number;hidden=($slide.SlideShowTransition.Hidden -eq -1);text=($texts -join "`n");speakerNotes=($notes -join "`n");renderedImage=[IO.Path]::GetFileName($target);fullPageViewed=$false}
 }
 $metadata=@{source=@{fileName=[IO.Path]::GetFileName($original);format=[IO.Path]::GetExtension($original).TrimStart('.').ToLowerInvariant();sha256=(Get-FileHash -LiteralPath $original -Algorithm SHA256).Hash.ToLowerInvariant();pageCount=$pages.Count};pages=@($pages);warning='PNG exported, not yet visually inspected.'}
 $json=$metadata | ConvertTo-Json -Depth 12
 [IO.File]::WriteAllText((Join-Path $output 'powerpoint-native.json'),$json,[Text.UTF8Encoding]::new($false))
 Write-Output ('Exported '+$pages.Count+' pages to '+$output)
} finally {
 if($presentation) { $presentation.Close();[void][Runtime.InteropServices.Marshal]::ReleaseComObject($presentation) }
 if($application) { if($null -ne $oldSecurity) { $application.AutomationSecurity=$oldSecurity };if($existing.Count -eq 0 -and $application.Presentations.Count -eq 0) { $application.Quit() };[void][Runtime.InteropServices.Marshal]::ReleaseComObject($application) }
}
