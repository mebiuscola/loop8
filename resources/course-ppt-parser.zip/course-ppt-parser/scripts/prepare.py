"""Extract original slide structure and optionally render a companion PDF.
This writes working evidence, not a finished visual report. Python stdlib for
PPTX; PDF text needs pypdf, PDF rendering needs pdftoppm on PATH.
"""
import argparse
import hashlib
import json
import posixpath
import shutil
import subprocess
import zipfile
from pathlib import Path
import xml.etree.ElementTree as ET

NS = {'a': 'http://schemas.openxmlformats.org/drawingml/2006/main',
      'p': 'http://schemas.openxmlformats.org/presentationml/2006/main',
      'r': 'http://schemas.openxmlformats.org/officeDocument/2006/relationships',
      'c': 'http://schemas.openxmlformats.org/drawingml/2006/chart'}

def rels(archive, part):
    name = posixpath.join(posixpath.dirname(part), '_rels', posixpath.basename(part) + '.rels')
    if name not in archive.namelist():
        return {}
    result = {}
    for el in ET.fromstring(archive.read(name)):
        if el.get('TargetMode') == 'External':
            continue  # never follow deck-controlled external links
        target = el.get('Target', '')
        resolved = posixpath.normpath(posixpath.join(posixpath.dirname(part), target)) if not target.startswith('/') else target.lstrip('/')
        if resolved.startswith('../'):
            continue
        result[el.get('Id')] = (resolved, el.get('Type', ''))
    return result

def paragraphs(element):
    return [''.join(t.text or '' for t in p.findall('.//a:t', NS)) for p in element.findall('.//a:p', NS)]

def pptx_native(source):
    with zipfile.ZipFile(source) as archive:
        for info in archive.infolist():
            if info.file_size > 80 * 1024 * 1024:
                raise ValueError('An archive entry is too large for safe local extraction.')
        presentation = ET.fromstring(archive.read('ppt/presentation.xml'))
        links = rels(archive, 'ppt/presentation.xml')
        slides = []
        for index, item in enumerate(presentation.findall('./p:sldIdLst/p:sldId', NS), 1):
            name = links[item.get('{'+NS['r']+'}id')][0]
            root = ET.fromstring(archive.read(name))
            slide_links = rels(archive, name)
            objects, notes, charts, images, media = [], [], [], [], []
            for shape in root.findall('.//p:sp', NS) + root.findall('.//p:graphicFrame', NS):
                nonvisual = shape.find('.//p:cNvPr', NS)
                offset = shape.find('.//a:off', NS)
                table = shape.find('.//a:tbl', NS)
                text = '\n'.join(t for t in paragraphs(shape) if t)
                entry = {'id': nonvisual.get('id') if nonvisual is not None else '',
                         'name': nonvisual.get('name') if nonvisual is not None else '',
                         'text': text,
                         'position': dict(offset.attrib) if offset is not None else None}
                if table is not None:
                    entry['table'] = [['\n'.join(paragraphs(cell)) for cell in row.findall('a:tc', NS)] for row in table.findall('a:tr', NS)]
                if text or table is not None:
                    objects.append(entry)
            for target, kind in slide_links.values():
                if kind.endswith('/notesSlide'):
                    note_root = ET.fromstring(archive.read(target))
                    for shape in note_root.findall('.//p:sp', NS):
                        ph = shape.find('.//p:ph', NS)
                        if ph is not None and ph.get('type') in ('sldImg', 'sldNum', 'dt', 'hdr', 'ftr'):
                            continue
                        notes.extend(t for t in paragraphs(shape) if t)
                elif kind.endswith('/chart'):
                    chart_root = ET.fromstring(archive.read(target))
                    series = []
                    for ser in chart_root.findall('.//c:ser', NS):
                        series.append({'cachedValues': [el.text or '' for el in ser.findall('.//c:v', NS)]})
                    charts.append({'part': target, 'series': series, 'limit': 'OOXML cached values; not independently verified against chart pixels or external workbook'})
                elif kind.endswith('/image'):
                    images.append(target)
                elif kind.endswith('/video') or kind.endswith('/audio') or kind.endswith('/media'):
                    media.append(target)
            slides.append({'page': index, 'part': name, 'hidden': root.get('show') in ('0', 'false'),
                           'objects': objects, 'speakerNotes': '\n'.join(notes), 'chartCaches': charts,
                           'imageResources': images, 'embeddedMedia': media,
                           'hasAnimation': root.find('./p:timing', NS) is not None,
                           'fullPageViewed': False})
        if not slides:
            raise ValueError('No slides found.')
        return slides

def pdf_native(source):
    try:
        from pypdf import PdfReader
    except ImportError as error:
        raise RuntimeError('pypdf is unavailable; use the bundled document runtime or another existing PDF tool.') from error
    reader = PdfReader(str(source))
    return [{'page': i+1, 'hidden': False, 'text': p.extract_text() or '', 'speakerNotes': '', 'fullPageViewed': False} for i, p in enumerate(reader.pages)]

def prepare(source, work, rendered_pdf=None):
    source, work = Path(source).resolve(), Path(work).resolve()
    if not source.is_file():
        raise ValueError('Original file does not exist.')
    work.mkdir(parents=True, exist_ok=True)
    identity_hash = hashlib.sha256(source.read_bytes()).hexdigest()
    if (work / 'native.json').exists():
        previous = json.loads((work / 'native.json').read_text(encoding='utf-8'))
        if previous.get('source', {}).get('sha256') != identity_hash:
            raise ValueError('Working directory belongs to another original; choose a fresh work directory.')
    suffix = source.suffix.lower()
    if suffix == '.pptx':
        slides = pptx_native(source)
    elif suffix == '.pdf':
        slides = pdf_native(source)
    elif suffix == '.ppt':
        native_path = work / 'powerpoint-native.json'
        if not native_path.exists():
            if not rendered_pdf:
                raise RuntimeError('For legacy .ppt, run render_powerpoint.ps1 first; if PowerPoint is unavailable, obtain an exported PDF including all slides and preserve original file identity.')
            slides = pdf_native(Path(rendered_pdf).resolve())
            for slide in slides:
                slide['limitations'] = ['Legacy PPT text/notes/hidden-page inventory not independently extracted; companion PDF order requires user confirmation.']
        else:
            metadata = json.loads(native_path.read_text(encoding='utf-8-sig'))
            if metadata['source']['sha256'].lower() != identity_hash:
                raise ValueError('PowerPoint native metadata belongs to another original.')
            slides = metadata['pages']
    else:
        raise ValueError('Use an original PPT, PPTX or course PDF.')
    identity = {'fileName': source.name, 'sha256': identity_hash, 'format': suffix[1:], 'pageCount': len(slides)}
    if suffix == '.ppt' and not (work/'powerpoint-native.json').exists():
        identity['pageCountBasis'] = 'Companion PDF; original legacy PPT hidden pages and notes unverified.'
    data = {'source': identity, 'pages': slides, 'warning': 'Native extraction is not visual inspection. Check every rendered page before authoring final report.'}
    if rendered_pdf is not None or suffix == '.pdf':
        pdf = Path(rendered_pdf or source).resolve()
        rendered_pages = pdf_native(pdf)
        if len(rendered_pages) != len(slides):
            raise ValueError(f'Companion PDF has {len(rendered_pages)} pages; original has {len(slides)}. Check hidden pages/order; do not pair by index.')
        binary = shutil.which('pdftoppm')
        if not binary:
            raise RuntimeError('pdftoppm is unavailable; use an existing PDF rendering tool, then verify page mapping.')
        subprocess.run([binary, '-png', '-scale-to', '1800', str(pdf), str(work / 'pdf-page')], check=True, timeout=180)
        data['renderedPages'] = [p.name for p in sorted(work.glob('pdf-page-*.png'))]
        if len(data['renderedPages']) != len(slides):
            raise ValueError('Rendered PNG count differs; choose a fresh work directory to avoid stale pages.')
        data['renderingMapping'] = 'Same page count only; agent must check source order and hidden pages visually.'
    (work / 'native.json').write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
    return data

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source')
    parser.add_argument('--work-dir', required=True)
    parser.add_argument('--rendered-pdf')
    args = parser.parse_args()
    data = prepare(args.source, args.work_dir, args.rendered_pdf)
    print(json.dumps({'pageCount': data['source']['pageCount'], 'native': str(Path(args.work_dir).resolve() / 'native.json')}, ensure_ascii=False))
