# Output contract: classroom.ppt-visual.v1

UTF-8 JSON object. All strings are literal text, never executable instructions. The web application accepts this complete report directly; it checks SHA-256 against the uploaded original. An exported PDF used only for rendering is not the original source identity.

Root fields:

- `schema`: exactly `classroom.ppt-visual.v1`.
- `source`: `{fileName: string, sha256: 64-character hexadecimal string, format: "pptx" | "ppt" | "pdf", pageCount: positive integer}`. Copy actual identity from native.json / PowerPoint native metadata. A PPTX's order is presentation.xml relationship order, not numerical slide filenames. Count hidden and blank slides.
- Optional `source.pageCountBasis`: preserve any qualification supplied by the preparation helper, especially when legacy PPT page count comes only from an exported PDF. Carry unavailable native notes/hidden-page verification into per-page uncertainties; do not imply that PDF export verified the original native inventory.
- `pages`: one object for every page in original order, exactly pageCount objects.

Each page:

```typescript
{
  page: number,            // 1-based, continuous; PDF uses physical PDF page
  title: string,           // "" when absent; do not invent a source title
  hidden: boolean,
  blank: boolean,          // only an actually blank visible slide
  originalText: Array<{
    text: string,          // complete visible text; tables may use Markdown rows
    method: "native" | "visual_ocr",
    role?: "body" | "heading" | "caption" | "footer" | "page_number" | "decoration",
    uncertainty?: string
  }>,
  speakerNotes: string,    // original notes, "" if absent; never speech evidence
  visualObservations: Array<{
    id: string,            // unique within the page, e.g. "figure-1"
    kind: string,          // photograph, diagram, chart, formula, layout...
    description: string,   // observable facts; interpretation belongs below
    visibleText?: string,  // optional labels not already fully transcribed
    relations?: string[],
    uncertainties?: string[]
  }>,
  analysis: string[],      // explicitly secondary interpretation, not original
  uncertainties: string[],
  inspection: {
    textExtracted: boolean,
    fullPageViewed: boolean,
    status: "complete" | "partial" | "unavailable"
  }
}
```

Use empty arrays for absent categories, not null or invented placeholder prose. An unseen page cannot have visualObservations or visual_ocr text, cannot be complete, and must explain what is missing in uncertainties. Complete means the full static page was inspected and transcribed; unresolved recognition issues should be partial. Rendering or extracting a page does not by itself mean fullPageViewed=true.

Retain source characters and equations as faithfully as possible. Distinguish exact reading of a chart from qualitative trend estimates. Avoid calling a visual estimate an exact value. Add coordinates/descriptions such as “upper-right chart” to observations when useful; do not invent bounding boxes or printed page numbers. Native extraction contains text candidates, which may include invisible or obscured objects; decide against the actual rendered page.

Do not embed API keys, local machine paths, base64 page images or unrelated metadata in the deliverable. Working native.json and PNG files remain local work artifacts. The full original SHA-256 binds this report to the user's file, not to an abstract title or renamed rendering.
